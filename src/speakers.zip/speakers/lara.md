---
title: 'Lara Mendonça'
summary: 'Design Lead at Bumble'
time: '14:00pm'
timeEnd: '14:40pm'
image: '/images/people/Lara.jpeg'
imageAlt: ''
displayOrder: 5
about: "<p>Lara leads the product design team at Bumble. Her focus is on building a collaborative and diverse team, and empowering Bumble in their mission to help people build healthy, safe and equal relationships. </p>

<p>Before that, she worked in product design and branding for a range of companies, including TransferWise, HSBC, Mitsubishi and Sky. She also volunteered at Pride in London, leading the redesign of their website.</p>

<p>When she's not working, you can find her reading fiction novels in public spaces, watching Scorsese films at home or travelling with her sister. Born and raised in Brazil, she currently lives in London with her family and her dog Miley.</p>"
talkDetails: 'Talk details coming soon...  '
---
