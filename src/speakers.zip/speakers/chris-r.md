---
title: 'Chris Richards'
summary: 'Creative Director at Nomensa'
time: '10:10am'
timeEnd: '10:50am'
image: '/images/people/chris-square.jpeg'
imageAlt: 'Chris Richards'
displayOrder: 2
about: "<p>Christopher's digital experience has moved from high-end emotionally driven creative, to functional and behavioural UX design, across a wide range of clients from commerce to government.</p>

<p>He's lived through the smart phone revelation, the age of responsive design, the golden age of UX and immersive tech and driven app experiences.  </p>"
talkDetails: 'Talk details coming soon...  '
---
