---
title: 'James Castro-Griffiths'
summary: 'Senior UI Designer at Nationwide'
time: '14:40pm'
timeEnd: '15:20pm'
image: '/images/people/James-CG.jpeg'
imageAlt: 'James Castro-Griffiths'
displayOrder: 6
about: "<p>Like in love, we leap before we think. Which is why I design experiences around why we all leap.</p>

<p>When I'm not designing I'm leaping around the countryside. Camping on river banks, or eating Wagon-Wheels on mountain tops. Taking photos and capturing as many memories as I can.</p>"
talkDetails: 'Talk details coming soon...  '
---
